import Main from "./components/Main";


function App() {
    return (
        <div className="App container mt-3">
            <div className="jumbotron">
                <h1 className="display-4">Hyperledger Fabric</h1>
                <p className="lead">This is a client application for Hyperledger Fabric</p>
                <hr className="my-4" />
            </div>
            <Main />
        </div>
    );
}

export default App;
